
package Modelo.sqlCompras;

public class Compras1 {
    private int idCompras;
    private double totalCompra;

    /**
     * @return the idCompras
     */
    public int getIdCompras() {
        return idCompras;
    }

    /**
     * @param idCompras the idCompras to set
     */
    public void setIdCompras(int idCompras) {
        this.idCompras = idCompras;
    }

    /**
     * @return the totalCompra
     */
    public double getTotalCompra() {
        return totalCompra;
    }

    /**
     * @param totalCompra the totalCompra to set
     */
    public void setTotalCompra(double totalCompra) {
        this.totalCompra = totalCompra;
    }
    
    
}
