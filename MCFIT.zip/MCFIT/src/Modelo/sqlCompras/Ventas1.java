
package Modelo.sqlCompras;

/**
 *
 * @author issacpuga
 */
public class Ventas1 {
    private int idPagoPr;
    private double totalVenta;

    public int getIdPagoPr() {
        return idPagoPr;
    }

    public void setIdPagoPr(int idPagoPr) {
        this.idPagoPr = idPagoPr;
    }

    public double getTotalVenta() {
        return totalVenta;
    }

    public void setTotalVenta(double totalVenta) {
        this.totalVenta = totalVenta;
    }
    
    
}
