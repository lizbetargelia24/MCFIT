/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo.Producto;
public class Proveedores {
    private int idProveedor; 
    private String nombreP;
    private String domicilio; 
    private String telefono; 
    private String codigoP; 
    private String nombreContacto; 
    private String email; 
    private String foto;

    public int getIdProveedor() {
        return idProveedor;
    }

    public String getNombreP() {
        return nombreP;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCodigoP() {
        return codigoP;
    }

    public String getNombreContacto() {
        return nombreContacto;
    }

    public String getEmail() {
        return email;
    }

    public String getFoto() {
        return foto;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCodigoP(String codigoP) {
        this.codigoP = codigoP;
    }

    public void setNombreContacto(String nombreContacto) {
        this.nombreContacto = nombreContacto;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
    
    
    
}
